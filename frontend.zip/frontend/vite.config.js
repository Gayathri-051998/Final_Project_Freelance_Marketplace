export default {
    server: {
      proxy: {
        '/api': 'https://final-project-freelance-marketplace.onrender.com',
      },
    },
  };
  