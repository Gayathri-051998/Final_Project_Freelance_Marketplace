const PaymentCancel = () => <div className="p-6 text-red-600 font-bold">❌ Payment was cancelled.</div>;
export default PaymentCancel;
