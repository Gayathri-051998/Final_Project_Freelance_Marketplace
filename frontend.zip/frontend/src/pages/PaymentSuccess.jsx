const PaymentSuccess = () => <div className="p-6 text-green-600 font-bold">✅ Payment successful!</div>;
export default PaymentSuccess;